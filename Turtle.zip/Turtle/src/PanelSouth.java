import java.awt.BorderLayout;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelSouth extends JPanel {
	/**
	 * It shows the status line and step counter. 
	 * @author Benny
	 */
	private static final long serialVersionUID = 1L;

	JLabel status = new JLabel("Ready");
	JLabel counter = new JLabel("Step counter:  0   ");

	public PanelSouth() {

		this.setLayout(new BorderLayout());

		this.add(new JLabel("  Status:  "), BorderLayout.WEST);
		this.add(counter, BorderLayout.EAST);

		this.add(status, BorderLayout.CENTER);
		status.setForeground(Color.green);

	}

}
