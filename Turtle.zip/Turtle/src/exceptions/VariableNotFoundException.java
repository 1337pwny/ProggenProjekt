package exceptions;
/**
 *@author Nils Rohde
 * Is thrown, if the desired variable could not be found.
 */
public class VariableNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public VariableNotFoundException(){
		
	}
	public VariableNotFoundException(String s){
		super(s);
	}
}
